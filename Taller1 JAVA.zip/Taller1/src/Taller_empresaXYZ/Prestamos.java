/*
Integrantes: Jorge Eduardo Torrado y Daniel Felipe Álvarez
Grupo 3
Octubre 7 de 2022
*/

package Taller_empresaXYZ;

public class Prestamos {
    public float calcular(int meses, float credito, float interes)
    {
      float total = meses*credito*interes;
      return total;
    }
}
