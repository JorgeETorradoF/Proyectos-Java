/*
Integrantes: Jorge Eduardo Torrado y Daniel Felipe Álvarez
Grupo 3
Octubre 7 de 2022
*/

package Taller_empresaXYZ;

import java.util.Scanner;

public class EmpresaXYZ
{

    public static void main(String[] args)
    {

        int opcion;

        Scanner inputNums = new Scanner(System.in);

        Scanner inputString = new Scanner(System.in);

        int meses;

        String nombreCliente;

        float credito;

        final float interes = (float) 0.1;

        float totalI;

        float precioTotal;

        Prestamos aPagar = new Prestamos();

        System.out.println("\nBienvenido, ingrese opción deseada:\n1 para cargar sus datos y con base en estos calcular interés del préstamo\n2 para terminar el programa");

        opcion = inputNums.nextInt();

        if (opcion != 2)
        {

            do
            {

                if (opcion != 1 && opcion != 2)
                {

                    // se decidió hacer este if do while como un reemplazo al while, ya que el primero, en teoría es más rápido para ejecutarse y por ende no se demora tanto en responder el programa

                    do
                    {

                        System.out.println("\nError, opción no válida, intente de nuevo:\n");

                        opcion = inputNums.nextInt();

                    }
                    while (opcion != 1 && opcion != 2);

                }

                System.out.println("\nIngrese nombre del cliente: ");

                nombreCliente = inputString.nextLine();

                System.out.println("\nIngrese valor del crédito solicitado: ");

                credito = inputNums.nextFloat();

                System.out.println("\nIngrese plazo en meses de la deuda: ");

                meses = inputNums.nextInt();

                totalI = aPagar.calcular(meses, credito, interes);

                precioTotal = credito + totalI;

                System.out.format("\nEl interés a pagar es: $%10.2f, que sumado con la deuda original da un valor total a pagar de: $%10.2f", totalI, precioTotal);

                System.out.println("\n\nIngrese opción deseada:\n1 para cargar sus datos y con base en estos calcular interés del préstamo\n2 para terminar el programa");

                opcion = inputNums.nextInt();

            }
            while (opcion != 2);
        }

    }

}