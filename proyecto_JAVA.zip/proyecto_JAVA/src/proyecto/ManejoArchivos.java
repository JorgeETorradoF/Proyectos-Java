package proyecto;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ManejoArchivos {
    private static ObjectInputStream oi = null;
    private static FileInputStream fi = null;
    private static ObjectOutputStream ou = null;
    private static FileOutputStream fo = null;
    private static final String ARCHIVOEQUIPO = "Equipos.dat";
    private static final String ARCHIVOPARTIDOS= "Partidos.dat";
    private static final String RUTA = "src/archivos";

    public static boolean validarCarpeta() {
        boolean rta = true;
        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        if (!carpeta.exists()) {
            if (carpeta.mkdirs()) {
                System.out.println("Carpeta creada");
            } else {
                System.out.println("Error, no se encuentra la carpeta");
                rta = false;
            }
        }
        return rta;
    }

    public static void abrirArchivoEquiposR() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator+RUTA);
        File archivoEquipos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOEQUIPO);
        boolean archivoExiste = false;
        if (archivoEquipos.length() > 0 && archivoEquipos.exists()) {
            archivoExiste = true;
        }
        try {
            fi = new FileInputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVOEQUIPO);
            oi = new ObjectInputStream(fi);
        } catch (FileNotFoundException ex) {
            oi = null;
            System.out.println("Archivo de Equipos no ha sido creado, por favor use alguna de las opciones de registro para crearlo");
        } catch (IOException ex) {
            oi = null;
            ex.printStackTrace();

        }

    }
    public static ArrayList leerEquipos()
    {
        ArrayList<InfoEquipo> equipos = new ArrayList<InfoEquipo>();
        if(validarCarpeta())
        {
            abrirArchivoEquiposR();
            if(oi != null)
            {
                try {
                    equipos = (ArrayList<InfoEquipo>) oi.readObject();
                } catch (EOFException ex) {
                    ex.printStackTrace();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
                try
                {
                    fi.close();
                    oi.close();
                }
                catch(IOException xd)
                {
                    System.out.println("Error al cerrar el archivo de equipos");
                }
            }
        }
        else
        {
            System.out.println("XD TE TROLEÓ");
        }
        return equipos;
    }
    public static ArrayList leerPartidos()
    {
        ArrayList<InfoPartido> partidos = new ArrayList<InfoPartido>();
        if(validarCarpeta())
        {
            abrirArchivoPartidosR();
            if(oi != null)
            {
                try {
                    partidos = (ArrayList<InfoPartido>) oi.readObject();
                } catch (EOFException ex) {
                    ex.printStackTrace();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
                try
                {
                    fi.close();
                    oi.close();
                }
                catch(IOException xd)
                {
                    System.out.println("Error al cerrar el archivo de equipos");
                }
            }
        }
        else
        {
            System.out.println("XD TE TROLEÓ");
        }
        return partidos;
    }
    public static void abrirArchivoPartidosR() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoPartidos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOPARTIDOS);
        boolean archivoExiste = false;
        if (archivoPartidos.length() > 0 && archivoPartidos.exists()) {
            archivoExiste = true;
        }
        try {
            fi = new FileInputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVOPARTIDOS);
            oi = new ObjectInputStream(fi);
        } catch (FileNotFoundException ex) {
            oi = null;
            System.out.println("Archivo de Partidos no ha sido creado, por favor use alguna de las opciones de registro para crearlo");
        } catch (IOException ex) {
            oi = null;
            ex.printStackTrace();

        }

    }

    public static void abrirArchivoEquiposW() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoEquipos= new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOEQUIPO);
        boolean archivoExiste = false;
        if (archivoEquipos.length() > 0 && archivoEquipos.exists()) {
            archivoExiste = true;
        }
        try {
            fo = new FileOutputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVOEQUIPO, true);
            if (!archivoExiste) {
                ou = new ObjectOutputStream(fo);
            } else {
                ou = new AppObjectOutputStream(fo);
            }
        } catch (FileNotFoundException ex) {
            ou = null;
            ex.printStackTrace();
        } catch (IOException ex) {
            ou = null;
            ex.printStackTrace();

        }

    }
    public static void escribirEquipos(ArrayList equipos)
    {
        if(validarCarpeta())
        {
            Path path = Paths.get("");
            String directoryName = path.toAbsolutePath().toString();
            File carpeta = new File(directoryName + File.separator + RUTA);
            File archivoEquipos= new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOEQUIPO);
            archivoEquipos.delete();
            abrirArchivoEquiposW();
            if(ou != null)
            {
                try {
                   ou.writeObject(equipos);
                } catch (EOFException ex) {
                    ex.printStackTrace();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
                try
                {
                    fo.close();
                    ou.close();
                }
                catch(IOException xd)
                {
                    System.out.println("Error al cerrar el archivo de equipos");
                }
            }
        }
    }
    public static void escribirPartidos(ArrayList partidos)
    {
        if(validarCarpeta())
        {
            Path path = Paths.get("");
            String directoryName = path.toAbsolutePath().toString();
            File carpeta = new File(directoryName + File.separator + RUTA);
            File archivoPartidos= new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOPARTIDOS);
            archivoPartidos.delete();
            abrirArchivoPartidosW();
            if(ou != null)
            {
                try {
                    ou.writeObject(partidos);
                } catch (EOFException ex) {
                    ex.printStackTrace();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
                try
                {
                    fo.close();
                    ou.close();
                }
                catch(IOException xd)
                {
                    System.out.println("Error al cerrar el archivo de equipos");
                }
            }
        }
    }
    public static void abrirArchivoPartidosW() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoPartidos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVOPARTIDOS);
        boolean archivoExiste = false;
        if (archivoPartidos.length() > 0 && archivoPartidos.exists()) {
            archivoExiste = true;
        }
        try {
            fo = new FileOutputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVOPARTIDOS, true);
            if (!archivoExiste) {
                ou = new ObjectOutputStream(fo);
            } else {
                ou = new AppObjectOutputStream(fo);
            }
        } catch (FileNotFoundException ex) {
            ou = null;
            ex.printStackTrace();
        } catch (IOException ex) {
            ou = null;
            ex.printStackTrace();

        }

    }
}
