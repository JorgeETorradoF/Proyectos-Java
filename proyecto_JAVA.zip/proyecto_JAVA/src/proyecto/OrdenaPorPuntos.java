package proyecto;

import java.util.Comparator;

public class OrdenaPorPuntos implements Comparator <InfoEquipo> {
    public int compare(InfoEquipo uno, InfoEquipo dos)
    {
        return dos.getPuntos()-uno.getPuntos();
    }
}
