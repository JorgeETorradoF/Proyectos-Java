package proyecto;

public class InfoPartido implements java.io.Serializable {
    private String local;
    private int golesLocal;
    private String visitante;
    private int golesVisitante;
    private String ganador;

    private String perdedor;

    public void setLocal(String local) {
        this.local = local;
    }

    public void setGolesLocal(int golesLocal) {
        this.golesLocal = golesLocal;
    }

    public void setVisitante(String visitante) {
        this.visitante = visitante;
    }

    public void setGolesVisitante(int golesVisitante) {
        this.golesVisitante = golesVisitante;
    }

    public void setGanador(String ganador) {
        this.ganador = ganador;
    }

    public void setPerdedor(String perdedor) {
        this.perdedor = perdedor;
    }

    public String getLocal() {
        return local;
    }

    public int getGolesLocal() {
        return golesLocal;
    }

    public String getVisitante() {
        return visitante;
    }

    public int getGolesVisitante() {
        return golesVisitante;
    }

    public String getGanador() {
        return ganador;
    }

    public String getPerdedor() {
        return perdedor;
    }

    public void calculaGanador()
    {
        if(golesLocal > golesVisitante)
        {
            ganador = local;
            perdedor = visitante;
        }
        if(golesVisitante>golesLocal)
        {
            ganador = visitante;
            perdedor = local;
        }
        if(golesVisitante == golesLocal)
        {
            this.ganador = "Empate";
            this.perdedor = "Empate";
        }
    }
}
