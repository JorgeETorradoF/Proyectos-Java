package proyecto;

import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;

public class Main
{
    public static void main(String[] args)
    {
        //se declaran variables

        Integer opcion = 1;
        Scanner inputStrings = new Scanner(System.in);
        Integer golesLocal;
        Integer golesVisitante;
        String nombre;
        boolean existe;
        boolean existeLocal;
        boolean existeVisitante;
        boolean stringEnInt;
        boolean opcionInvalida;
        boolean volverAlMenu;
        boolean existeCarpeta;
        ArrayList<InfoEquipo> equipos = new ArrayList<InfoEquipo>();
        ArrayList<InfoPartido> partidos = new ArrayList<InfoPartido>();

        equipos = ManejoArchivos.leerEquipos();
        partidos = ManejoArchivos.leerPartidos();
        //codigo del menu y procesamiento de opciones

        while(opcion !=5)
        {
            opcionInvalida = true;
            opcion = compruebaOpcion(inputStrings,opcionInvalida);
            switch (opcion)
            {
                case 1:
                    volverAlMenu = false;
                    existe = true;
                    System.out.println("Ingrese nombre del equipo a registrar (Ingrese la palabra salir para volver al menú principal): ");
                    nombre = inputStrings.nextLine();
                    if((volverAlMenu = compruebaSalir(nombre)))
                    {
                        break;
                    }
                    Iterator indice1 = equipos.iterator();
                    while (existe)
                    {
                        existe = existeEquipo(indice1,nombre);
                        if(existe)
                        {
                            System.out.println("Error, el equipo ya existe, intente de nuevo(Ingrese la palabra salir para volver al menú principal):");
                            nombre = inputStrings.nextLine();
                            if((volverAlMenu = compruebaSalir(nombre)))
                            {
                                break;
                            }
                        }
                        else
                        {
                            InfoEquipo registro = new InfoEquipo(nombre);
                            equipos.add(registro);
                            System.out.println(("Equipo registrado correctamente"));
                            break;
                        }
                    }
                    break;
                case 2:
                    volverAlMenu = false;
                    existeLocal = false;
                    existeVisitante = false;
                    stringEnInt = true;
                    InfoPartido partido = new InfoPartido();

                    //local

                    do
                    {
                        Iterator indice2a = equipos.iterator();
                        System.out.println("Ingrese nombre del equipo local (ingrese la palabra salir para volver al menú):");
                        nombre = inputStrings.nextLine();
                        if((volverAlMenu = compruebaSalir(nombre)))
                        {
                            break;
                        }
                        if((existeLocal = existeEquipo(indice2a,nombre)))
                        {
                            partido.setLocal(nombre);
                        }
                        else
                        {
                            System.out.println("\nError, ese equipo no existe");
                        }
                    }
                    while(!existeLocal);
                    if(volverAlMenu)
                    {
                        break;
                    }
                    while(stringEnInt)
                    {
                        try
                        {
                            stringEnInt = false;
                            System.out.println("Ingrese goles del equipo local (ingrese 99 para volver al menú principal):");
                            golesLocal = Integer.parseInt(inputStrings.nextLine());
                            if((volverAlMenu = compruebaSalir(golesLocal)))
                            {
                                break;
                            }
                            while(golesLocal <0)
                            {
                                System.out.println("Error, solo se admiten numeros enteros mayores o iguales a 0");
                                golesLocal = Integer.parseInt(inputStrings.nextLine());
                            }
                            partido.setGolesLocal(golesLocal);
                        }
                        catch(NumberFormatException ex)
                        {
                            stringEnInt = true;
                            System.out.println("Error, solo se admiten entradas que sean numeros enteros");
                        }
                    }
                    if(volverAlMenu)
                    {
                        break;
                    }

                    //visitante

                    while(!existeVisitante)
                    {
                        Iterator indice2b = equipos.iterator();
                        System.out.println("Ingrese nombre del equipo visitante (ingrese la palabra salir para volver al menú):");
                        nombre = inputStrings.nextLine();
                        if((volverAlMenu = compruebaSalir(nombre)))
                        {
                            break;
                        }
                        while(nombre.equals(partido.getLocal()))
                        {
                            System.out.println("Error, un equipo no puede enfrentarse a si mismo, ingrese de nuevo el visitante:");
                            nombre = inputStrings.nextLine();
                        }
                        if((existeVisitante = existeEquipo(indice2b,nombre)))
                        {
                            partido.setVisitante(nombre);
                        }
                        else
                        {
                            System.out.println("\nError, ese equipo no existe");
                        }
                    }
                    if(volverAlMenu)
                    {
                        break;
                    }
                    stringEnInt = true;
                    while(stringEnInt)
                    {
                        try
                        {
                            stringEnInt = false;
                            System.out.println("Ingrese goles del equipo visitante (ingrese 99 para volver al menú principal):");
                            golesVisitante= Integer.parseInt(inputStrings.nextLine());
                            if((volverAlMenu = compruebaSalir(golesVisitante)))
                            {
                                break;
                            }
                            while(golesVisitante <0)
                            {
                                System.out.println("Error, solo se admiten numeros enteros mayores o iguales a 0");
                                golesVisitante = Integer.parseInt(inputStrings.nextLine());
                            }
                            partido.setGolesVisitante(golesVisitante);
                        }
                        catch(NumberFormatException ex)
                        {
                            stringEnInt = true;
                            System.out.println("Error, solo se admiten entradas que sean numeros enteros");
                        }
                    }
                    if(volverAlMenu)
                    {
                        break;
                    }
                    partidos.add(partido);
                    partido.calculaGanador();
                    actualizarEquipos(partido, equipos);
                    ordenar(equipos);
                    break;
                case 3:
                    opcion3(equipos);
                    break;
                case 4:
                    opcion4(partidos);
                    break;
            }
            ManejoArchivos.escribirEquipos(equipos);
            ManejoArchivos.escribirPartidos(partidos);
        }
    }

    //funciones auxiliares del main (relacionadas con archivos)
    public static void actualizarEquipos(InfoPartido partido, ArrayList equipos)
    {
        Iterator actualizar1 = equipos.iterator();
        Iterator actualizar2 = equipos.iterator();
        InfoEquipo actualizado1 = new InfoEquipo();
        InfoEquipo actualizado2 = new InfoEquipo();
        int contador = -1;
        while(actualizar1.hasNext())
        {
            InfoEquipo aux = new InfoEquipo();
            aux = (InfoEquipo) actualizar1.next();
            contador++;
            //actualizo al local

            if(aux.getNombre().equals(partido.getLocal()))
            {
                actualizado1 = aux;
                actualizado1.setGolesAFavor(actualizado1.getGolesAFavor() + partido.getGolesLocal());
                actualizado1.setGolesEnContra(actualizado1.getGolesEnContra() + partido.getGolesVisitante());
                if(partido.getGanador().equals(actualizado1.getNombre()))
                {
                    actualizado1.setPartidosGanados(actualizado1.getPartidosGanados()+1);
                    actualizado1.setPuntos(actualizado1.getPuntos() + 3);
                }
                if (partido.getGanador().equals("Empate"))
                {
                    actualizado1.setPartidosEmpatados(actualizado1.getPartidosEmpatados()+1);
                    actualizado1.setPuntos(actualizado1.getPuntos() + 1);
                }
                if(partido.getPerdedor().equals(actualizado1.getNombre()))
                {
                    actualizado1.setPartidosPerdidos(actualizado1.getPartidosPerdidos()+1);
                }
                actualizado1.calculaJugados();
                equipos.set(contador,actualizado1);
            }

            //actualizo al visitante

            if(aux.getNombre().equals(partido.getVisitante()))
            {
                actualizado2 = aux;
                actualizado2.setGolesAFavor(actualizado2.getGolesAFavor() + partido.getGolesVisitante());
                actualizado2.setGolesEnContra(actualizado2.getGolesEnContra() + partido.getGolesLocal());
                if(partido.getGanador().equals(actualizado2.getNombre()))
                {
                    actualizado2.setPartidosGanados(actualizado2.getPartidosGanados()+1);
                    actualizado2.setPuntos(actualizado2.getPuntos() + 3);
                }
                if (partido.getGanador().equals("Empate"))
                {
                    actualizado2.setPartidosEmpatados(actualizado2.getPartidosEmpatados()+1);
                    actualizado2.setPuntos(actualizado2.getPuntos() + 1);
                }
                if (partido.getPerdedor().equals(actualizado2.getNombre()))
                {
                    actualizado2.setPartidosPerdidos(actualizado2.getPartidosPerdidos()+1);
                }
                actualizado2.calculaJugados();
                equipos.set(contador, actualizado2);
            }
        }
    }
    public static void ordenar(ArrayList equipos)
    {

        Collections.sort(equipos, new OrdenaPorPuntos());
    }
    public static boolean existeEquipo(Iterator i, String nombre)
    {
        boolean existe = false;
        while (i.hasNext())
        {
            InfoEquipo aux = new InfoEquipo();
            aux = (InfoEquipo) i.next();
            if (aux.getNombre().equals(nombre))
            {
                existe = true;
                break;
            }
        }
        return existe;
    }
    public static boolean compruebaSalir(String nombre)
    {
        boolean salir = false;
        if(nombre.toLowerCase().equals("salir"))
        {
            salir = true;
        }
        return salir;
    }
    public static boolean compruebaSalir(int goles)
    {
        boolean salir = false;
        if(goles == 99)
        {
            salir = true;
        }
        return salir;
    }
    public static int compruebaOpcion(Scanner inputStrings, boolean opcionInvalida)
    {
        int opcion = 1;
        while (opcionInvalida)
        {
            try
            {
                opcionInvalida = false;
                System.out.println("\nBienvenido, elija la opción deseada:\n1 Para Registrar un equipo\n2 Para registrar un partido\n3 Para mostrar la tabla de posiciones\n4 Para mostrar el histórico de partidos jugados\n5 Para salir");
                opcion = Integer.parseInt(inputStrings.nextLine());
                while(opcion <1 || opcion>5)
                {
                    System.out.println("\nError, solo se pueden numeros del 1 al 5 para la opción, intente de nuevo");
                    opcion = Integer.parseInt(inputStrings.nextLine());
                }

            }
            catch(NumberFormatException ex)
            {
                opcionInvalida = true;
                System.out.println("\nError, tipo de dato erróneo, intente de nuevo");
            }
        }
        return opcion;
    }
    public static void opcion3(ArrayList equipos)
    {
        int contadorPos = 0;
        Iterator indice3 =  equipos.iterator();
        if(indice3.hasNext())
        {
            System.out.format("%25s|%10s|%10s|%10s|%10s|%10s|%10s|%10s|%10s|%10s|\n","Equipo","Pos","ptos","J","G","E","P","GF","GC","DG");
            System.out.println("_______________________________________________________________________________________________________________________________");
        }
        else
        {
            System.out.println("\nError, no se cuenta con datos de equipos registrados");
        }
        while(indice3.hasNext())
        {
            contadorPos++;
            InfoEquipo aux = new InfoEquipo();
            aux = (InfoEquipo) indice3.next();
            System.out.format("%25s|%10d|%10d|%10d|%10d|%10d|%10d|%10d|%10d|%10d|\n", aux.getNombre(),contadorPos,aux.getPuntos(),aux.getPartidosJugados(),aux.getPartidosGanados(),aux.getPartidosEmpatados(),aux.getPartidosPerdidos(),aux.getGolesAFavor(),aux.getGolesEnContra(),(aux.getGolesAFavor()-aux.getGolesEnContra()));
            System.out.println("_______________________________________________________________________________________________________________________________");
        }
    }
    public static void opcion4(ArrayList partidos)
    {
        Iterator indice4 = partidos.iterator();
        if(indice4.hasNext())
        {
            System.out.format("%-25s |%-15s |%-25s |%-15s", "Local", "Goles Local", "Visitante", "Goles Visitante\n");
            System.out.println("_______________________________________________________________________________________________________________________________");
        }
        else
        {
            System.out.println("Error, no se cuenta con información de partidos jugados");
        }
        while(indice4.hasNext())
        {
            InfoPartido auxPartidos = new InfoPartido();
            auxPartidos = (InfoPartido) indice4.next();
            System.out.format("%-25s |%-15d |%-25s |%-15d\n", auxPartidos.getLocal(), auxPartidos.getGolesLocal(), auxPartidos.getVisitante(), auxPartidos.getGolesVisitante());
            System.out.println("_______________________________________________________________________________________________________________________________");
        }
    }
}