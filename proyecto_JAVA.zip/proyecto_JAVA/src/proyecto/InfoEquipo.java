package proyecto;

public class InfoEquipo implements java.io.Serializable {
    private int puntos = 0;
    private String nombre ="";
    private int golesAFavor = 0;
    private int golesEnContra = 0;
    private int partidosGanados = 0;
    private int partidosPerdidos = 0;
    private int partidosEmpatados = 0;
    private int partidosJugados;
    public InfoEquipo()
    {

    }
    public InfoEquipo(String nombre)
    {
        this.nombre = nombre;
    }
    public void setNombre(String nombre)
    {

        this.nombre = nombre;
    }
    public void setGolesAFavor(int golesAFavor)
    {

        this.golesAFavor=golesAFavor;
    }
    public void setGolesEnContra(int golesEnContra)
    {

        this.golesEnContra = golesEnContra;
    }
    public void setPartidosGanados(int partidosGanados)
    {

        this.partidosGanados = partidosGanados;
    }
    public void setPartidosPerdidos(int partidosPerdidos)
    {

        this.partidosPerdidos = partidosPerdidos;
    }
    public void setPartidosEmpatados(int partidosEmpatados)
    {

        this.partidosEmpatados = partidosEmpatados;
    }
    public void setPuntos(int puntos)
    {

        this.puntos = puntos;
    }
    public String getNombre ()
    {
        return this.nombre;
    }
    public int getPartidosEmpatados()
    {

        return this.partidosEmpatados;
    }
    public int getPartidosPerdidos()
    {

        return this.partidosPerdidos;
    }
    public int getPartidosGanados()
    {

        return this.partidosGanados;
    }
    public int getGolesAFavor()
    {

        return this.golesAFavor;
    }
    public int getGolesEnContra()
    {

        return this.golesEnContra;
    }
    public int getPuntos()
    {

        return this.puntos;
    }
    public void calculaJugados()
    {
        this.partidosJugados = this.partidosEmpatados+this.partidosPerdidos+this.partidosGanados;
    }
    public int getPartidosJugados()
    {
        return this.partidosJugados;
    }
}
