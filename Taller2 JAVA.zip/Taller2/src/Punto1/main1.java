/*
Integrantes: Jorge Eduardo Torrado y Daniel Felipe Álvarez
Grupo 3
Octubre 7 de 2022
*/


package Punto1;

import java.util.Scanner;

public class main1 {

    public static void main(String[] args)
    {


        Scanner teclado=new Scanner(System.in);

        String frase,palabra;

        boolean fin=true;

        int contador=0, pos=0;

        System.out.println("Digite su palabra");

        frase=teclado.nextLine();

        System.out.println("Digite fragmento a buscar en la palabra");

        palabra=teclado.nextLine();

        while(fin){

            int a = frase.indexOf(palabra, pos);

            if(a!=-1){

                pos = a + palabra.length();

                contador++;

            }else{

                fin=false;

            }

            //System.out.println("actual " + pos);

        }

        System.out.format("hay %d incidencias del fragmento en la palabra ingresada", contador);

    }
}
