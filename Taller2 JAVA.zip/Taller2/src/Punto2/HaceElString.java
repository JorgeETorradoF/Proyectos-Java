/*
Integrantes: Jorge Eduardo Torrado y Daniel Felipe Álvarez
Grupo 3
Octubre 7 de 2022
*/

package Punto2;

public class HaceElString

{
    private String palabrainput;

    private String arreglo[];

    private int tam;

    public HaceElString(String palabrainput)

    {

        this.palabrainput = palabrainput;

        tam = this.palabrainput.length();

        arreglo = new String[tam];

    }

    public void divide()
    {

        arreglo = this.palabrainput.split(" ");
    }

    public void imprime()

    {

        for(String a: arreglo)

        {

            System.out.format("%s:%d\n",a,a.length());

        }

    }

}
