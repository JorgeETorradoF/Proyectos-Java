/*
Integrantes: Jorge Eduardo Torrado y Daniel Felipe Álvarez
Grupo 3
Octubre 7 de 2022
*/

package Punto2;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args)

    {

        Scanner input = new Scanner(System.in);

        String cadena;

        System.out.println("\nBienvenido, ingrese un string: ");

        cadena = input.nextLine();

        HaceElString respuesta = new HaceElString(cadena);

        respuesta.divide();

        respuesta.imprime();

    }
}
