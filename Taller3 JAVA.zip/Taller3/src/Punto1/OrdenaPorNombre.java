package Punto1;

import java.util.Comparator;

public class OrdenaPorNombre implements Comparator<Trabajador>
{
    public int compare(Trabajador uno, Trabajador dos)
    {
        return uno.getNombres().compareTo(dos.getNombres());
    }
}
