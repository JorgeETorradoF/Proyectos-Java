package Punto1;/*
Integrantes: Jorge Torrado y Daneil Álvarez
Grupo: 3
Fecha: 23/10/2022
Posdata, como en el taller no se pidió manejo de excepciones, no se tomó en cuenta las comparaciones de que si ambos empleados tenian el mismo codigo, etc.
*/


import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        int opcion;
        Scanner inputNums = new Scanner(System.in);
        Scanner inputString = new Scanner(System.in);
        //esta linea de abajo aparentemente, dependiendo de la version del jdk va con () o sin el ()
        ArrayList<Trabajador> empleados = new ArrayList<Trabajador>();
        Trabajador aux = new Trabajador();
        int codigo;
        String nombres;
        String apellidos;
        String area;
        float sueldo;
        do
        {
            System.out.println(  "\nSeleccione opción:\n1. Añadir nuevo trabajador\n2. Mostrar lista de trabajadores\n3. Borrar trabajador \n4. Editar trabajador\n5. Ordenar trabajadores por nombre\n6. Salir");
            opcion = inputNums.nextInt();
            switch (opcion)
            {
                case 1:
                    System.out.println("Ingrese código del empleado: ");
                    codigo = inputNums.nextInt();
                    System.out.println("Ingrese nombres del empleado: ");
                    nombres = inputString.nextLine();
                    System.out.println("Ingrese apellidos del empleado: ");
                    apellidos = inputString.nextLine();
                    System.out.println("Ingrese área del empleado: ");
                    area = inputString.nextLine();
                    System.out.println("Ingrese salario del empleado: ");
                    sueldo = inputNums.nextFloat();
                    empleados.add(new Trabajador(codigo,nombres,apellidos,area,sueldo));
                    break;
                case 2:
                    int contador2 = 0;
                    Iterator indice2 = empleados.iterator();
                    while(indice2.hasNext())
                    {
                        contador2++;
                        aux = (Trabajador) indice2.next();
                        System.out.format("\n\nEmpleado número: %d\nCódigo: %-15d\nNombre: %-15s\nApellidos: %-15s\nArea: %-15s\nSueldo: %15.2f\n", contador2, aux.getCodigo(), aux.getNombres(), aux.getApellidos(), aux.getArea(), aux.getSueldo());
                    }
                    break;
                case 3:
                    System.out.println("Ingrese codigo del empleado a eliminar: ");
                    codigo = inputNums.nextInt();
                    Iterator indice3 = empleados.iterator();
                    while(indice3.hasNext())
                    {
                        aux = (Trabajador) indice3.next();
                        if(aux.getCodigo() == codigo)
                        {
                            empleados.remove(aux);
                            break;
                        }
                    }
                    break;
                case 4:
                    boolean existe = false;
                    int contador4 = -1;
                    System.out.println("Ingrese codigo del empleado a modificar: ");
                    codigo = inputNums.nextInt();
                    System.out.println("Ingrese nuevo sueldo del empleado: ");
                    sueldo = inputNums.nextInt();
                    Iterator indice4 = empleados.iterator();
                    while(indice4.hasNext())
                    {
                        contador4++;
                        aux = (Trabajador) indice4.next();
                        if(aux.getCodigo() == codigo)
                        {
                            existe = true;
                            aux.setSueldo(sueldo);
                            empleados.set(contador4,aux);
                            break;
                        }
                    }
                    if (existe == false)
                    {
                        System.out.println("Error, el empleado no existe");
                    }
                    break;
                case 5:
                    Collections.sort(empleados, new OrdenaPorNombre());
                    int contador5 = 0;
                    Iterator indice5 = empleados.iterator();
                    while(indice5.hasNext())
                    {
                        contador5++;
                        aux = (Trabajador) indice5.next();
                        System.out.format("\n\nEmpleado número: %d\nCódigo: %-15d\nNombre: %-15s\nApellidos: %-15s\nArea: %-15s\nSueldo: %15.2f", contador5, aux.getCodigo(), aux.getNombres(), aux.getApellidos(), aux.getArea(), aux.getSueldo());
                    }
                    break;
        }
    }while(opcion !=6);
}
}