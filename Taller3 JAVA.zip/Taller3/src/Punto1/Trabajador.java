package Punto1;

public class Trabajador {
    private int codigo;
    private String nombres;
    private String apellidos;
    private String area;
    private float sueldo;
    public Trabajador()
    {

    }
    public Trabajador(int codigo, String nombres, String apellidos, String area, float sueldo)
    {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos=apellidos;
        this.area=area;
        this.sueldo=sueldo;
    }
    public String getNombres()
    {

        return this.nombres;
    }
    public int getCodigo()
    {

        return this.codigo;
    }
    public String getApellidos()
    {

        return this.apellidos;
    }
    public String getArea()
    {

        return this.area;
    }
    public float getSueldo()
    {

        return this.sueldo;
    }
    public void setSueldo(float sueldo)
    {

        this.sueldo = sueldo;
    }
}
